<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es-ES" lang="es-ES">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Contacte con nosotros - lavasecototal.co</title>
	<meta name="description" content="Servicios asequibles de lavandería y lavado en seco.">
	<meta name="keywords" content="lavado en seco,lavandería,plancha,limpieza">
	<meta name="generator" content="Web Presence Builder 12.5.29">
	<link rel="stylesheet" type="text/css" href="../../css/facebook.css?template=facebook">
	<style type="text/css">
		
	</style>
	<link type="text/css" href="../../modules/navigation/navigation.css?template=facebook" rel="stylesheet" />
<script type="text/javascript" src="../../components/jquery/jquery.min.js?ac=12.5.29_43615.15081314"></script>
<link type="text/css" href="../../css/text-ab60d2dc-6857-872e-937c-ec9fc82f332b.css?template=facebook" rel="stylesheet" />
<link type="text/css" href="../../modules/text/text.css?template=facebook" rel="stylesheet" />
<script type="text/javascript" src="../../modules/text/text.js?ac=12.5.29_43615.15081314"></script>
<script type="text/javascript" src="../../components/jquery/jquery.validate.js?ac=12.5.29_43615.15081314"></script>
<script type="text/javascript" src="../../components/jquery/jquery.textarea-expander.js?ac=12.5.29_43615.15081314"></script>
<script type="text/javascript" src="../../js/jquery.validate.localization.js?ac=12.5.29_43615.15081314"></script>
<script type="text/javascript" src="https://www.google.com/recaptcha/api/js/recaptcha_ajax.js?ac=12.5.29_43615.15081314"></script>
<script type="text/javascript">var siteBuilderJs = jQuery.noConflict(true);</script>
	
	
</head>
<body class="">
	<div class="widget widget-navigation " id="widget-e5d309c3-6b1f-2788-9921-da3385b32df8">
	<div class="widget-content"><a id="navigation-toggle-e5d309c3-6b1f-2788-9921-da3385b32df8" target="_top"></a><ul class="navigation" id="navigation-e5d309c3-6b1f-2788-9921-da3385b32df8">
			<li class="normal">
			<a href="../../fb/">
				<span class="navigation-item-bullet">></span>
				<span class="navigation-item-text">Inicio</span>
			</a>
			
		</li><li class="normal">
			<a href="../../fb/services/">
				<span class="navigation-item-bullet">></span>
				<span class="navigation-item-text">Servicios</span>
			</a>
			
		</li><li class="normal">
			<a href="../../fb/locations/">
				<span class="navigation-item-bullet">></span>
				<span class="navigation-item-text">Dónde encontrarnos</span>
			</a>
			
		</li><li class="normal">
			<a href="../../fb/testimonials/">
				<span class="navigation-item-bullet">></span>
				<span class="navigation-item-text">Testimonios</span>
			</a>
			
		</li><li class="normal">
			<a href="../../fb/coupons-discounts/">
				<span class="navigation-item-bullet">></span>
				<span class="navigation-item-text">Cupones y descuentos</span>
			</a>
			
		</li><li class="normal">
			<a href="../../fb/careers/">
				<span class="navigation-item-bullet">></span>
				<span class="navigation-item-text">Empleo</span>
			</a>
			
		</li><li class="normal">
			<a href="../../fb/online-shop/">
				<span class="navigation-item-bullet">></span>
				<span class="navigation-item-text">Tienda online</span>
			</a>
			
		</li><li class="selected ">
			<a href="../../fb/contact-us/">
				<span class="navigation-item-bullet">></span>
				<span class="navigation-item-text">Contacte con nosotros</span>
			</a>
			
		</li>
	</ul></div>
</div><div class="widget widget-text " id="widget-ab60d2dc-6857-872e-937c-ec9fc82f332b">
	<div class="widget-content"><p>Si desea solicitar nuestros servicios de limpieza con recogida y entrega a domicilio gratuita, llame al Mi teléfono, envíe un email a javiles@hostingred.com o rellene el formulario que aparece a continuación.</p></div>
</div><div class="widget widget-contact " id="widget-4bf69771-6137-82e3-433b-9929855bfaec">
	<div class="widget-content"><form id="widget-4bf69771-6137-82e3-433b-9929855bfaec-form" action="">
		<div class="form-item">
		<label class="form-item-label" for="widget-4bf69771-6137-82e3-433b-9929855bfaec-field-name">Nombre <span class="form-required">*</span></label><input type="text" id="widget-4bf69771-6137-82e3-433b-9929855bfaec-field-name" name="name" class="form-item-textfield required"  />
	</div>
		<div class="form-item">
		<label class="form-item-label" for="widget-4bf69771-6137-82e3-433b-9929855bfaec-field-mail">Email <span class="form-required">*</span></label><input type="text" id="widget-4bf69771-6137-82e3-433b-9929855bfaec-field-mail" name="mail" class="form-item-textfield required email"  />
	</div>
		<div class="form-item">
		<label class="form-item-label" for="widget-4bf69771-6137-82e3-433b-9929855bfaec-field-message">Mensaje <span class="form-required">*</span></label><textarea id="widget-4bf69771-6137-82e3-433b-9929855bfaec-field-message" name="message" class="form-item-textarea expand100-200 required"></textarea>
	</div>
		<div class="form-item">
		<div class="form-item-captcha" style="display: none;"><label class="form-item-label">Introduzca los símbolos que aparecen abajo para demostrar que es usted humano. <span class="form-required">*</span></label><div class="recaptcha" id="recaptcha-4bf69771-6137-82e3-433b-9929855bfaec"></div><input type="hidden" name="captcha" /></div>
	</div>
		<div class="form-note">Los campos marcados con <span class="form-required">*</span> son obligatorios.</div>
	<input type="submit" class="form-submit" value="Send e-mail">
	<input type="hidden" name="uuid" value="4bf69771-6137-82e3-433b-9929855bfaec">
</form></div>
</div>
	<script type="text/javascript" src="../../js/anti_cache.js?ac=12.5.29_43615.15081314"></script>
<div style="border-top: 1px solid #EEEEEE; padding: 5px 10px; text-align: right;">
	<a href="../../contact-us/" target="_blank">Abrir lavasecototal.co</a>
</div>
<div id="fb-root" style="display: none;"></div>
<script type="text/javascript">window.fbAsyncInit = function() {
	FB.init({
		appId: '162438790477380', // App ID
		status: true, // check login status
		cookie: true, // enable cookies to allow the server to access the session
		oauth: true, // enable OAuth 2.0
		xfbml: true // parse XFBML
	});
	FB.Canvas.setSize();
}</script><script type="text/javascript" src="//connect.facebook.net/en_US/all.js?ac=12.5.29_43615.15081314"></script>
<script type="text/javascript">
window.mobileSwitcherText = "Cambiar al sitio completo";
window.desktopSwitcherText = "Cambiar a la versión móvil";
</script><script type="text/javascript">
siteBuilderJs(document).ready(function ($) {
		$.addImagesAnimation('#widget-ab60d2dc-6857-872e-937c-ec9fc82f332b');	var showCaptcha = function(form, captchaEnabled) {
		$(".form-item-captcha").hide();
		if (captchaEnabled) {
			var captcha = form.find(".recaptcha").first();
			Recaptcha.create("6LcIkNMSAAAAAKGiQbpqqijO3DeMBhuqjRJN1k9L", captcha.attr('id'), {lang: "es", theme: "clean"});
			form.find(".form-item-captcha").slideDown();
		}
	};

	$("#widget-4bf69771-6137-82e3-433b-9929855bfaec input, #widget-4bf69771-6137-82e3-433b-9929855bfaec textarea").focus(function() {
		var form = $(this).closest("form"),
			captchaContainer = form.find(".form-item-captcha");
		if (captchaContainer.length != 0 && !captchaContainer.is(':visible')) {
			showCaptcha(form, true);
		}
	});

	$("#widget-4bf69771-6137-82e3-433b-9929855bfaec form").validate({
		submitHandler: function(form) {
			var validator = this,
				showError = function () {
					alert("No se ha podido enviar su mensaje debido a un error interno. Contacte con el administrador del sitio web por otros medios para informarle de este problema.");
				};

			if ($(form).find(".form-item-captcha").length !=0 && !$(form).find(".form-item-captcha").is(":visible")) {
				showCaptcha(form, true);
			}				$.ajax({
					type: "POST",
					url: "../../modules/contact/send.php",
					data: $(form).serialize(),
					dataType: 'json',
					success: function(data) {
						if (data && data.result) {
							form.reset();
							Recaptcha.reload();
							alert(data.message);
						} else if (data && 'badCaptcha' == data.code) {
							Recaptcha.reload();
							validator.showErrors({'captcha': data.message});
						} else {
							showError();
						}
					},
					error: showError
				});		}
	});
});
</script>
</body>
</html>