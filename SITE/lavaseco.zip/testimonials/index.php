<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es-ES" lang="es-ES">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Testimonios - lavasecototal.co</title>
	<meta name="description" content="Servicios asequibles de lavandería y lavado en seco.">
	<meta name="keywords" content="lavado en seco,lavandería,plancha,limpieza">
	<meta name="generator" content="Web Presence Builder 12.5.29">
	<link type="text/css" rel="stylesheet" href="../css/style.css?template=generic">
	<style type="text/css">
		#widget-56066176-9d5e-42dd-aac9-2074bde331dd {
	margin: 0 0 0 0;
	padding: 0 0 0 0;
	border-radius: 0 0 0 0;
}
#widget-56066176-9d5e-42dd-aac9-2074bde331dd {box-shadow: none}
#widget-e42d445c-9982-48e4-945b-1a444c3f120b {
	margin: 0 0 0 0;
	padding: 0 0 0 0;
	border-radius: 0 0 0 0;
}
#widget-e42d445c-9982-48e4-945b-1a444c3f120b {box-shadow: none}
#widget-32c637c9-08e6-499e-a93c-e8308b34f9b1 {
	margin: 0 0 0 0;
	padding: 10px 10px 10px 10px;
	border-radius: 0 0 0 0;
}
#widget-32c637c9-08e6-499e-a93c-e8308b34f9b1 {box-shadow: none}
#widget-c09acafc-3d42-3ffd-2388-d4274e3d5461 {
	margin: 0 0 0 0;
	padding: 5px 10px 5px 10px;
	border-radius: 0 0 0 0;
}
#widget-c09acafc-3d42-3ffd-2388-d4274e3d5461 {box-shadow: none}
#widget-e0517975-db94-81a1-db8b-182f3142a581 {
	margin: 0 0 0 0;
	padding: 5px 10px 5px 10px;
	border-radius: 0 0 0 0;
}
#widget-e0517975-db94-81a1-db8b-182f3142a581 {box-shadow: none}
#widget-6f60d651-f39f-478f-8071-3660127f7940 {
	margin: 0 0 0 0;
	padding: 0 0 0 0;
	border-radius: 0 0 0 0;
}
#widget-6f60d651-f39f-478f-8071-3660127f7940 {box-shadow: none}
#widget-1debea2c-2f85-4277-aa88-bc0dd96d2b2e {
	margin: 0 0 0 0;
	padding: 0 0 0 0;
	border-radius: 0 0 0 0;
}
#widget-1debea2c-2f85-4277-aa88-bc0dd96d2b2e {box-shadow: none}
#widget-ea5ecbeb-31ea-4601-9d0a-83ea7e53899e {
	margin: 0 0 0 0;
	padding: 0 0 0 0;
	border-radius: 0 0 0 0;
}
#widget-ea5ecbeb-31ea-4601-9d0a-83ea7e53899e {box-shadow: none}
#widget-89b2c7db-7d4f-4fcb-bb60-c274250366fe {
	margin: 0 0 0 0;
	padding: 0 0 0 0;
	border-radius: 0 0 0 0;
}
#widget-89b2c7db-7d4f-4fcb-bb60-c274250366fe {box-shadow: none}
#widget-a18f75a3-0529-4cb9-a871-1971f94e2a82 {
	margin: 0px 30px 0px 0px;
	padding: 10px 10px 10px 10px;
	border-radius: 0px 0px 10px 10px;
}
#widget-a18f75a3-0529-4cb9-a871-1971f94e2a82 {
background-color: rgba(180,180,180,1);
}
#widget-a18f75a3-0529-4cb9-a871-1971f94e2a82 {box-shadow: none}
#widget-dfb94903-3b09-4b86-a160-c99e20984326 {
	margin: 25px 0px 0px 0px;
	padding: 0px 0px 0px 0px;
	border-radius: 1px 1px 1px 1px;
}
#widget-dfb94903-3b09-4b86-a160-c99e20984326 {box-shadow: none}
#widget-241af162-75c0-4a1e-8e6b-96baa9628209 {
	margin: 0 0 0 0;
	padding: 0 0 0 0;
	border-radius: 0 0 0 0;
}
#widget-241af162-75c0-4a1e-8e6b-96baa9628209 {box-shadow: none}
#widget-e4e7c30a-c5ae-444c-a6c2-67945f2c38a6 {
	margin: 0 0 0 0;
	padding: 5px 20px 5px 20px;
	border-radius: 0 0 0 0;
}
#widget-e4e7c30a-c5ae-444c-a6c2-67945f2c38a6 {box-shadow: none}
#widget-aee91b9d-faf4-45f8-9928-6795afccd196 {
	margin: 0px 0px 0px 0px;
	padding: 5px 10px 6px 10px;
	border-radius: 0 0 0 0;
}
#widget-aee91b9d-faf4-45f8-9928-6795afccd196 {
	background-image: linear-gradient(to bottom,rgba(125,125,125,0.4),rgba(180,180,180,0.4));
	background-size: 100% 100%;
}
#widget-aee91b9d-faf4-45f8-9928-6795afccd196 {box-shadow: none}
#widget-73a7080e-3cb5-406d-95b8-4fafa659d336 {
	margin: 0px 0px 0px 0px;
	padding: 15px 20px 0px 20px;
	border-radius: 0 0 0 0;
}
#widget-73a7080e-3cb5-406d-95b8-4fafa659d336 {box-shadow: none}
#widget-44961338-61cb-4a02-bd04-e8e94fccb373 {
	margin: 0 0 0 0;
	padding: 0px 20px 15px 20px;
	border-radius: 0 0 0 0;
}
#widget-44961338-61cb-4a02-bd04-e8e94fccb373 {box-shadow: none}
#widget-5a18d78e-26e5-4d61-8a84-c47eeafd4450 {
	margin: 0 0 0 0;
	padding: 10px 10px 10px 10px;
	border-radius: 0 0 0 0;
}
#widget-5a18d78e-26e5-4d61-8a84-c47eeafd4450 {box-shadow: none}
#widget-0e3c3747-57b7-1344-a9cb-49a443d86e33 {
	margin: 0 0 0 0;
	padding: 5px 10px 5px 10px;
	border-radius: 0 0 0 0;
}
#widget-0e3c3747-57b7-1344-a9cb-49a443d86e33 {box-shadow: none}
#widget-8a1b327e-c2bc-4178-818e-cfbdae48d896 {
	margin: 0 0 0 0;
	padding: 9px 9px 9px 9px;
	border-radius: 0 0 0 0;
}
#widget-8a1b327e-c2bc-4178-818e-cfbdae48d896 {
background-color: rgba(218,218,218,0.44);
}
#widget-8a1b327e-c2bc-4178-818e-cfbdae48d896 {box-shadow: none}
#widget-e5eabaee-81a7-4b90-a398-48b6cb5ba7d2 {
	margin: 0 0 0 0;
	padding: 0 0 0 0;
	border-radius: 0 0 0 0;
}
#widget-e5eabaee-81a7-4b90-a398-48b6cb5ba7d2 .header-image {
				box-shadow: inset 0px 0px 12px 9px rgba(0,0,0,0.1);
			}#widget-f98d32ea-ae3d-4a16-84c8-b3aff49b9600 {
	margin: 0 0 0 0;
	padding: 10px 10px 5px 10px;
	border-radius: 0 0 0 0;
}
#widget-f98d32ea-ae3d-4a16-84c8-b3aff49b9600 {box-shadow: none}
#widget-112298c9-11a8-452d-b8d5-d35988471ec0 {
	margin: 0 0 0 0;
	padding: 0 0 0 0;
	border-radius: 0 0 0 0;
}
#widget-112298c9-11a8-452d-b8d5-d35988471ec0 {box-shadow: none}
#widget-7557a74c-7a1c-475e-8489-867c3582ade9 {
	margin: 0 0 0 0;
	padding: 10px 10px 10px 10px;
	border-radius: 0 0 0 0;
}
#widget-7557a74c-7a1c-475e-8489-867c3582ade9 {box-shadow: none}
#widget-dda36565-06ac-05b9-9136-49ee47957f17 {
	margin: 0 0 0 0;
	padding: 5px 10px 5px 10px;
	border-radius: 0 0 0 0;
}
#widget-dda36565-06ac-05b9-9136-49ee47957f17 {box-shadow: none}
#widget-efd0d8e6-3fc4-4a7b-a0be-e9b4633d0e5e {
	margin: 0 0 0 0;
	padding: 0 0 0 0;
	border-radius: 0 0 0 0;
}
#widget-efd0d8e6-3fc4-4a7b-a0be-e9b4633d0e5e {box-shadow: none}
#widget-618da8fa-4c4f-4b6c-915d-14754677602b {
	margin: 0 0 0 0;
	padding: 0 0 0 0;
	border-radius: 0 0 0 0;
}
#widget-618da8fa-4c4f-4b6c-915d-14754677602b {box-shadow: none}
#widget-db472928-43e5-49c6-8018-030e8a5b5901 {
	margin: 0 0 0 0;
	padding: 5px 10px 5px 10px;
	border-radius: 0 0 0 0;
}
#widget-db472928-43e5-49c6-8018-030e8a5b5901 {box-shadow: none}
#widget-ef822add-3a77-4295-9170-434b9f03d8cb {
	margin: 0 0 0 0;
	padding: 0px 0px 0px 0px;
	border-radius: 0 0 0 0;
}
#widget-ef822add-3a77-4295-9170-434b9f03d8cb {box-shadow: none}
body{background-color:#f4f7f8;}#column1-content{
			background-image: linear-gradient(to top,rgba(206,206,206,1),rgba(229,229,229,1));
			background-size: 100% 100%;
		}#column2-content{
			background-image: linear-gradient(to top,rgba(206,206,206,1),rgba(229,229,229,1));
			background-size: 100% 100%;
		}#column1-content,#column1-content .container-content-inner {border-radius:10px 10px 10px 10px;}
#column2-content,#column2-content .container-content-inner {border-radius:10px 10px 10px 10px;}
#header-content,#header-content .container-content-inner {border-radius:0 0 10px 10px;}
#footer-content,#footer-content .container-content-inner {border-radius:10px 10px 10px 10px;}

	</style>
	<script type="text/javascript" src="../js/css_browser_selector.js"></script>
	<link type="text/css" href="../modules/navigation/navigation.css?template=generic" rel="stylesheet" />
<script type="text/javascript" src="../components/jquery/jquery.min.js?ac=12.5.29_43615.15081314"></script>
<link type="text/css" href="../css/text-c09acafc-3d42-3ffd-2388-d4274e3d5461.css?template=generic" rel="stylesheet" />
<link type="text/css" href="../modules/text/text.css?template=generic" rel="stylesheet" />
<script type="text/javascript" src="../modules/text/text.js?ac=12.5.29_43615.15081314"></script>
<script type="text/javascript" src="../components/jquery/jquery.validate.js?ac=12.5.29_43615.15081314"></script>
<script type="text/javascript" src="../components/jquery/jquery.textarea-expander.js?ac=12.5.29_43615.15081314"></script>
<script type="text/javascript" src="../js/jquery.validate.localization.js?ac=12.5.29_43615.15081314"></script>
<script type="text/javascript" src="https://www.google.com/recaptcha/api/js/recaptcha_ajax.js?ac=12.5.29_43615.15081314"></script>
<link type="text/css" href="../css/navigation-dfb94903-3b09-4b86-a160-c99e20984326.css?template=generic" rel="stylesheet" />
<link type="text/css" href="//fonts.googleapis.com/css?family=Dosis&subset=latin%2Clatin-ext" rel="stylesheet" />
<link type="text/css" href="../css/text-e4e7c30a-c5ae-444c-a6c2-67945f2c38a6.css?template=generic" rel="stylesheet" />
<link type="text/css" href="../css/text-aee91b9d-faf4-45f8-9928-6795afccd196.css?template=generic" rel="stylesheet" />
<link type="text/css" href="../css/text-73a7080e-3cb5-406d-95b8-4fafa659d336.css?template=generic" rel="stylesheet" />
<link type="text/css" href="../css/text-44961338-61cb-4a02-bd04-e8e94fccb373.css?template=generic" rel="stylesheet" />
<link type="text/css" href="../css/text-0e3c3747-57b7-1344-a9cb-49a443d86e33.css?template=generic" rel="stylesheet" />
<link type="text/css" href="../css/text-8a1b327e-c2bc-4178-818e-cfbdae48d896.css?template=generic" rel="stylesheet" />
<link type="text/css" href="../css/header-e5eabaee-81a7-4b90-a398-48b6cb5ba7d2.css?template=generic" rel="stylesheet" />
<link type="text/css" href="../css/text-f98d32ea-ae3d-4a16-84c8-b3aff49b9600.css?template=generic" rel="stylesheet" />
<link type="text/css" href="../css/text-dda36565-06ac-05b9-9136-49ee47957f17.css?template=generic" rel="stylesheet" />
<link type="text/css" href="../css/text-db472928-43e5-49c6-8018-030e8a5b5901.css?template=generic" rel="stylesheet" />
<link type="text/css" href="../css/text-ef822add-3a77-4295-9170-434b9f03d8cb.css?template=generic" rel="stylesheet" />
<link type="text/css" href="../css/layout.css?template=generic" rel="stylesheet" />
<script type="text/javascript">var siteBuilderJs = jQuery.noConflict(true);</script>
	
	<script type="text/javascript" src="../js/helpers.js"></script>
	<script type="text/javascript" src="../js/view.js"></script>
	
</head>
<body id="template" class="">
	<div class="unsupported">La versión de su navegador no está debidamente actualizada. Le recomendamos actualizarla a la versión más reciente.</div><div id="page">
	<div id="watermark" class="border-none">
		<div class="external-top">
			<div class="external-top-left"></div>
			<div class="external-top-right"></div>
			<div class="external-top-center"><div><div></div></div></div>
		</div>
		<div class="external-middle">
			<div class="external-left"><div><div></div></div></div>
			<div class="external-right"><div><div></div></div></div>
			<div class="watermark-content"></div>
		</div>
		<div class="external-bottom">
			<div class="external-bottom-left"></div>
			<div class="external-bottom-right"></div>
			<div class="external-bottom-center"><div><div></div></div></div>
		</div>
	</div>
	<div id="layout" class="pageContentText">
		<div id="layout-header">
			<div id="header" class="container header border-none">
	<div id="header-top" class="top"><div><div></div></div></div>
	<div id="header-side" class="side"><div id="header-side2" class="side2">
		<div class="container-content">
			<div id="header-content">
				<div class="container-content-inner" id="header-content-inner">
	<table class="widget-columns-table"><tr><td class="widget-columns-column" style="width: 34.202%"><div class="widget widget-site_logo " id="widget-a18f75a3-0529-4cb9-a871-1971f94e2a82">
	<div class="widget-content"><div style='text-align: center;'><a href="../"><img src="../attachments/builtin/Logo/white.png?template=generic" alt=""  /></a></div></div>
</div></td><td class="widget-columns-column" style="width: 65.798%"><div class="widget widget-navigation " id="widget-dfb94903-3b09-4b86-a160-c99e20984326">
	<div class="widget-content"><a id="navigation-toggle-dfb94903-3b09-4b86-a160-c99e20984326"></a><ul class="navigation" id="navigation-dfb94903-3b09-4b86-a160-c99e20984326">
			<li class="normal">
			<a href="../">
				<span class="navigation-item-bullet">></span>
				<span class="navigation-item-text">Inicio</span>
			</a>
			
		</li><li class="normal">
			<a href="../services/">
				<span class="navigation-item-bullet">></span>
				<span class="navigation-item-text">Servicios</span>
			</a>
			
		</li><li class="normal">
			<a href="../locations/">
				<span class="navigation-item-bullet">></span>
				<span class="navigation-item-text">Dónde encontrarnos</span>
			</a>
			
		</li><li class="selected ">
			<a href="../testimonials/">
				<span class="navigation-item-bullet">></span>
				<span class="navigation-item-text">Testimonios</span>
			</a>
			
		</li><li class="normal">
			<a href="../coupons-discounts/">
				<span class="navigation-item-bullet">></span>
				<span class="navigation-item-text">Cupones y descuentos</span>
			</a>
			
		</li><li class="normal">
			<a href="../careers/">
				<span class="navigation-item-bullet">></span>
				<span class="navigation-item-text">Empleo</span>
			</a>
			
		</li><li class="normal">
			<a href="../online-shop/">
				<span class="navigation-item-bullet">></span>
				<span class="navigation-item-text">Tienda online</span>
			</a>
			
		</li><li class="normal">
			<a href="../contact-us/">
				<span class="navigation-item-bullet">></span>
				<span class="navigation-item-text">Contacte con nosotros</span>
			</a>
			
		</li>
	</ul></div>
</div></td></tr></table>
</div>
			</div>
		</div>
	</div></div>
	<div id="header-bottom" class="bottom"><div><div></div></div></div>
</div>
		</div>
		<div id="layout-content">
			<div id="columns">
				<div id="column1" class="container column1 column column-left border-none">
	<div id="column1-top" class="top"><div><div></div></div></div>
	<div id="column1-side" class="side"><div id="column1-side2" class="side2">
		<div class="container-content">
			<div id="column1-content">
				<div class="container-content-inner" id="column1-content-inner">
	<div class="widget widget-text " id="widget-e4e7c30a-c5ae-444c-a6c2-67945f2c38a6">
	<div class="widget-content"><h2><span>Diam nonummy nibh!</span></h2></div>
</div>

	<div class="widget widget-text " id="widget-aee91b9d-faf4-45f8-9928-6795afccd196">
	<div class="widget-content"><p><span style="font-weight: bold; font-size: 16px; color: #ffffff;"><span style="font-weight: bold; font-size: 16px; color: #ffffff;"><span class="image-block  caption-over-image" style="float: left; margin-right: 10px; width:45px;"><img id="mce-4998" src="../attachments/Image/icon-06.png?template=generic" alt="" width="45" height="45"></img></span></span></span></p>
<h2><span style="color: #091118;"><span style="font-weight: bold; font-size: 16px;">Duis autem vel eum iriure dolor in&nbsp;hendre!</span></span></h2></div>
</div>

	<div class="widget widget-text " id="widget-73a7080e-3cb5-406d-95b8-4fafa659d336">
	<div class="widget-content"><p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>
<p><span><a class=" link" href="../">Lorem &gt;&gt;</a></span></p></div>
</div>

	<div class="widget widget-text " id="widget-44961338-61cb-4a02-bd04-e8e94fccb373">
	<div class="widget-content"><p>Ipsum factorial non deposit quid pro quo hic escorol. Olypian quarrels et gorilla congolium sic ad nauseum.</p>
<p><span><a class=" link" href="../">Lorem &gt;&gt;</a></span></p></div>
</div>

	<div class="widget widget-pagecontent " id="widget-5a18d78e-26e5-4d61-8a84-c47eeafd4450">
	<div class="widget-content"><div class="widget widget-text " id="widget-0e3c3747-57b7-1344-a9cb-49a443d86e33">
	<div class="widget-content"></div>
</div></div>
</div>

	<div class="widget widget-text " id="widget-8a1b327e-c2bc-4178-818e-cfbdae48d896">
	<div class="widget-content"><h2 style="text-align: center;"><span style="font-size: 22px; color: #000000;">ADIPISCING ELIT</span><span style="font-family: Dosis, sans-serif; font-weight: bold; color: #16aaf5;"><br /></span></h2></div>
</div>

	<div class="widget widget-header " id="widget-e5eabaee-81a7-4b90-a398-48b6cb5ba7d2">
	<div class="widget-content"><div class="header-image"></div></div>
</div>

	<div class="widget widget-text " id="widget-f98d32ea-ae3d-4a16-84c8-b3aff49b9600">
	<div class="widget-content"><h2 style="text-align: center;"><span style="font-size: 18px; color: #2e3e4c;"><a class=" link" href="../">LOREM IPSUM</a></span></h2></div>
</div>
</div>
			</div>
		</div>
	</div></div>
	<div id="column1-bottom" class="bottom"><div><div></div></div></div>
</div>
				
				<div id="content" class="container content border-none">
	<div id="content-top" class="top"><div><div></div></div></div>
	<div id="content-side" class="side"><div id="content-side2" class="side2">
		<div class="container-content">
			<div id="content-content">
				<div class="container-content-inner" id="content-content-inner">
	

	

	<div class="widget widget-pagecontent " id="widget-32c637c9-08e6-499e-a93c-e8308b34f9b1">
	<div class="widget-content"><div class="widget widget-text " id="widget-c09acafc-3d42-3ffd-2388-d4274e3d5461">
	<div class="widget-content"><p><span style="font-weight: bold;">Roberto Sanchís:</span></p>
<p>Estoy encantado de haber encontrado a lavasecototal. Recogieron mis edredones en mi casa y me los devolvieron el día siguientes, limpios y como si fueran nuevos. Un servicio increíble a un precio razonable. Sin duda recomiendo lavasecototal a mis amigos y conocidos.</p>
<p>&nbsp;</p>
<p><span style="font-weight: bold;">Envíenos sus comentarios</span></p></div>
</div><div class="widget widget-contact " id="widget-e0517975-db94-81a1-db8b-182f3142a581">
	<div class="widget-content"><form id="widget-e0517975-db94-81a1-db8b-182f3142a581-form" action="">
		<div class="form-item">
		<label class="form-item-label" for="widget-e0517975-db94-81a1-db8b-182f3142a581-field-name">Nombre <span class="form-required">*</span></label><input type="text" id="widget-e0517975-db94-81a1-db8b-182f3142a581-field-name" name="name" class="form-item-textfield required"  />
	</div>
		<div class="form-item">
		<label class="form-item-label" for="widget-e0517975-db94-81a1-db8b-182f3142a581-field-mail">Email <span class="form-required">*</span></label><input type="text" id="widget-e0517975-db94-81a1-db8b-182f3142a581-field-mail" name="mail" class="form-item-textfield required email"  />
	</div>
		<div class="form-item">
		<label class="form-item-label" for="widget-e0517975-db94-81a1-db8b-182f3142a581-field-message">Mensaje <span class="form-required">*</span></label><textarea id="widget-e0517975-db94-81a1-db8b-182f3142a581-field-message" name="message" class="form-item-textarea expand100-200 required"></textarea>
	</div>
		<div class="form-item">
		<div class="form-item-captcha" style="display: none;"><label class="form-item-label">Introduzca los símbolos que aparecen abajo para demostrar que es usted humano. <span class="form-required">*</span></label><div class="recaptcha" id="recaptcha-e0517975-db94-81a1-db8b-182f3142a581"></div><input type="hidden" name="captcha" /></div>
	</div>
		<div class="form-note">Los campos marcados con <span class="form-required">*</span> son obligatorios.</div>
	<input type="submit" class="form-submit" value="Send e-mail">
	<input type="hidden" name="uuid" value="e0517975-db94-81a1-db8b-182f3142a581">
</form></div>
</div></div>
</div>

	

	<table class="widget-columns-table"><tr><td class="widget-columns-column" style="width: 50%"></td><td class="widget-columns-column" style="width: 50%"></td></tr></table>

	

	<table class="widget-columns-table"><tr><td class="widget-columns-column" style="width: 50%"></td><td class="widget-columns-column" style="width: 50%"></td></tr></table>
</div>
			</div>
		</div>
	</div></div>
	<div id="content-bottom" class="bottom"><div><div></div></div></div>
</div>
			</div>
		</div>
		<div id="layout-footer">
			<div id="footer" class="container footer border-none">
	<div id="footer-top" class="top"><div><div></div></div></div>
	<div id="footer-side" class="side"><div id="footer-side2" class="side2">
		<div class="container-content">
			<div id="footer-content">
				<div class="container-content-inner" id="footer-content-inner">
	<table class="widget-columns-table"><tr><td class="widget-columns-column" style="width: 35.46%"><div class="widget widget-text " id="widget-db472928-43e5-49c6-8018-030e8a5b5901">
	<div class="widget-content">&nbsp;</div>
</div></td><td class="widget-columns-column" style="width: 64.54%"><div class="widget widget-text " id="widget-ef822add-3a77-4295-9170-434b9f03d8cb">
	<div class="widget-content"><p style="text-align: left;"><span>&copy; 2014. lavasecototal. All Rights Reserved.</span></p></div>
</div></td></tr></table>
<div class="mobile-view-switcher"></div></div>
			</div>
		</div>
	</div></div>
	<div id="footer-bottom" class="bottom"><div><div></div></div></div>
</div>
		</div>
		
	</div>
</div>
	<script type="text/javascript" src="../js/anti_cache.js?ac=12.5.29_43615.15081314"></script>
<script type="text/javascript">
window.mobileSwitcherText = "Cambiar al sitio completo";
window.desktopSwitcherText = "Cambiar a la versión móvil";
</script><script type="text/javascript">
siteBuilderJs(document).ready(function ($) {
		$.addImagesAnimation('#widget-c09acafc-3d42-3ffd-2388-d4274e3d5461');	var showCaptcha = function(form, captchaEnabled) {
		$(".form-item-captcha").hide();
		if (captchaEnabled) {
			var captcha = form.find(".recaptcha").first();
			Recaptcha.create("6LcIkNMSAAAAAKGiQbpqqijO3DeMBhuqjRJN1k9L", captcha.attr('id'), {lang: "es", theme: "clean"});
			form.find(".form-item-captcha").slideDown();
		}
	};

	$("#widget-e0517975-db94-81a1-db8b-182f3142a581 input, #widget-e0517975-db94-81a1-db8b-182f3142a581 textarea").focus(function() {
		var form = $(this).closest("form"),
			captchaContainer = form.find(".form-item-captcha");
		if (captchaContainer.length != 0 && !captchaContainer.is(':visible')) {
			showCaptcha(form, true);
		}
	});

	$("#widget-e0517975-db94-81a1-db8b-182f3142a581 form").validate({
		submitHandler: function(form) {
			var validator = this,
				showError = function () {
					alert("No se ha podido enviar su mensaje debido a un error interno. Contacte con el administrador del sitio web por otros medios para informarle de este problema.");
				};

			if ($(form).find(".form-item-captcha").length !=0 && !$(form).find(".form-item-captcha").is(":visible")) {
				showCaptcha(form, true);
			}				$.ajax({
					type: "POST",
					url: "../modules/contact/send.php",
					data: $(form).serialize(),
					dataType: 'json',
					success: function(data) {
						if (data && data.result) {
							form.reset();
							Recaptcha.reload();
							alert(data.message);
						} else if (data && 'badCaptcha' == data.code) {
							Recaptcha.reload();
							validator.showErrors({'captcha': data.message});
						} else {
							showError();
						}
					},
					error: showError
				});		}
	});$("#navigation-toggle-dfb94903-3b09-4b86-a160-c99e20984326").click(function(e) {
				e.preventDefault();
				$("#navigation-dfb94903-3b09-4b86-a160-c99e20984326").slideToggle();
			});
	$.addImagesAnimation('#widget-e4e7c30a-c5ae-444c-a6c2-67945f2c38a6');	$.addImagesAnimation('#widget-aee91b9d-faf4-45f8-9928-6795afccd196');	$.addImagesAnimation('#widget-73a7080e-3cb5-406d-95b8-4fafa659d336');	$.addImagesAnimation('#widget-44961338-61cb-4a02-bd04-e8e94fccb373');	$.addImagesAnimation('#widget-0e3c3747-57b7-1344-a9cb-49a443d86e33');	$.addImagesAnimation('#widget-8a1b327e-c2bc-4178-818e-cfbdae48d896');	$.addImagesAnimation('#widget-f98d32ea-ae3d-4a16-84c8-b3aff49b9600');	$.addImagesAnimation('#widget-dda36565-06ac-05b9-9136-49ee47957f17');	$.addImagesAnimation('#widget-db472928-43e5-49c6-8018-030e8a5b5901');	$.addImagesAnimation('#widget-ef822add-3a77-4295-9170-434b9f03d8cb');
});
</script>
</body>
</html>